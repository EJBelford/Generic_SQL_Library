 
    INSERT INTO GB_generic_Processes (process_Key, process_Description, status) 
        VALUES ( -1,   'NOT APPLICABLE', 'C');
    INSERT INTO GB_generic_Processes (process_Key, process_Description, status) 
        VALUES (  1,   'pr_generic_insUpd_processLog', 'C');
    INSERT INTO GB_generic_Processes (process_Key, process_Description, status) 
        VALUES (  10,  'pr_generic_processlog_Cleanup', 'C');
    INSERT INTO GB_generic_Processes (process_Key, process_Description, status) 
        VALUES (  11,  'pr_generic_stdDebugTbl_Del', 'C');
    INSERT INTO GB_generic_Processes (process_Key, process_Description, status) 
        VALUES (  100, 'maintain_generic_warehouse', 'C'); 
    INSERT INTO GB_generic_Processes (process_Key, process_Description, status) 
        VALUES (  101, 'pr_generic_item_part_load', 'C'); 
